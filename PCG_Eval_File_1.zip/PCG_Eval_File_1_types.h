/* Copyright 2007 The MathWorks, Inc. */
/*
 * File: PCG_Eval_File_4_types.h
 *
 * Real-Time Workshop code generated for Simulink model PCG_Eval_File_4.
 *
 * Model version                        : 1.222
 * Real-Time Workshop file version      : 6.6  (R2007a Prerelease)  08-Jan-2007
 * Real-Time Workshop file generated on : Thu Jan 18 11:17:54 2007
 * TLC version                          : 6.6 (Jan  9 2007)
 * C source code generated on           : Thu Jan 18 11:17:55 2007
 */

#ifndef _RTW_HEADER_PCG_Eval_File_4_types_h_
#define _RTW_HEADER_PCG_Eval_File_4_types_h_
/*********
#ifdef EXTERN_C
  #undef EXTERN_C
  #endif

  #ifdef __cplusplus
  #define EXTERN_C                       extern "C"
  #else
  #define EXTERN_C                       extern
  #endif
/*********/
#ifdef __cplusplus
extern "C" {
#endif


#include "ThrottleBus.h"

#ifdef __cplusplus
}
#endif

#endif                                 /* _RTW_HEADER_PCG_Eval_File_4_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
